import { useState, useEffect } from "react";
import { getFaces, nameFace } from "./api";
import "./App.css";

function App() {
  const [faces, setFaces] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function fetchFaces() {
      try {
        const data = await getFaces();
        console.log("Fetched faces:", data);
        setFaces(data);
      } catch (err) {
        setError(err.message);
      }
    }
    fetchFaces();
  }, []);

  const handleRename = async (faceId, newName) => {
    try {
      await nameFace(faceId, newName);
      setFaces(
        faces.map((face) =>
          face.FaceId === faceId ? { ...face, Name: newName } : face
        )
      );
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="App">
      <h1>Face Gallery</h1>
      {error && <p className="error">{error}</p>}
      <div className="gallery">
        {faces.map((face) => (
          <div key={face.FaceId} className="face-card">
            <img
              src={`https://ombckt342003.s3.ap-south-1.amazonaws.com/${face.ImageKey}`}
              alt={face.Name || "Unknown"}
            />
            <p>{face.Name || "Unknown"}</p>
            <input
              type="text"
              placeholder="Enter name"
              onBlur={(e) => handleRename(face.FaceId, e.target.value)}
            />
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;
