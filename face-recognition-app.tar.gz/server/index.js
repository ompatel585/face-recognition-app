const express = require('express');
const cors = require('cors');
const axios = require('axios');
const { handleImageUpload } = require('./rekognition');
const { listAllFaces, assignName } = require('./db');

const app = express();
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.text({ type: '*/*' }));

app.get('/faces', async (req, res) => {
    try {
        const faces = await listAllFaces();
        console.log('Fetched faces:', faces);
        res.json(faces);
    } catch (err) {
        console.error('Error fetching faces:', err.message);
        res.status(500).send('Error fetching faces');
    }
});

app.post('/name', async (req, res) => {
    try {
        const { faceId, name } = req.body;
        await assignName(faceId, name);
        res.status(200).send('Name updated');
    } catch (err) {
        console.error('Error naming face:', err.message);
        res.status(500).send('Failed to name face');
    }
});

app.post('/s3-event', async (req, res) => {
    try {
        console.log('SNS Headers:', JSON.stringify(req.headers, null, 2));
        console.log('SNS Raw Body:', req.body);
        let snsMessage;
        try {
            snsMessage = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
        } catch (err) {
            console.error('Error parsing SNS message:', err.message);
            return res.status(400).json({ error: 'Invalid SNS message' });
        }

        console.log('SNS Message:', JSON.stringify(snsMessage, null, 2));
        const messageType = req.headers['x-amz-sns-message-type'];

        if (messageType === 'SubscriptionConfirmation') {
            const subscribeURL = snsMessage.SubscribeURL;
            console.log('🦒 Confirming SNS Subscription:', subscribeURL);
            await axios.get(subscribeURL);
            console.log('✅ SNS Subscription confirmed');
            return res.status(200).send('Subscription confirmed');
        }

        const message = JSON.parse(snsMessage.Message);
        const s3Event = message.Records[0].s3;
        const bucket = s3Event.bucket.name;
        const key = s3Event.object.key;

        console.log(`📸 New Image Uploaded: ${key} in bucket ${bucket}`);
        await handleImageUpload(bucket, key);
        res.status(200).send('OK');
    } catch (err) {
        console.error('❌ Error processing SNS event:', err.message);
        res.status(500).send('Error');
    }
});

app.listen(4000, () => {
    console.log('🚀 App listening on http://0.0.0.0:4000');
});