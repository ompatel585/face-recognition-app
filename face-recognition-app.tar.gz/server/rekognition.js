const AWS = require('aws-sdk');
const { saveFaceMetadata } = require('./db');

AWS.config.update({ region: 'ap-south-1' });

const rekognition = new AWS.Rekognition();
const COLLECTION_ID = 'face-collection-om';

async function ensureCollectionExists() {
    try {
        await rekognition.createCollection({ CollectionId: COLLECTION_ID }).promise();
        console.log('✅ Rekognition collection created.');
    } catch (err) {
        if (err.code !== 'ResourceAlreadyExistsException') {
            console.error("❌ Error creating collection:", err.message);
            throw err;
        }
    }
}

async function handleImageUpload(bucket, key) {
    try {
        await ensureCollectionExists();
        const params = {
            CollectionId: COLLECTION_ID,
            Image: {
                S3Object: { Bucket: bucket, Name: key }
            },
            MaxFaces: 1,
            FaceMatchThreshold: 95
        };
        const indexData = await rekognition.indexFaces(params).promise();
        if (indexData.FaceRecords.length === 0) {
            console.log('No faces detected');
            return;
        }
        const faceId = indexData.FaceRecords[0].Face.FaceId;

        // Search for similar faces
        const searchParams = {
            CollectionId: COLLECTION_ID,
            FaceId: faceId,
            MaxFaces: 10,
            FaceMatchThreshold: 95
        };
        const searchData = await rekognition.searchFaces(searchParams).promise();
        let finalFaceId = faceId;
        if (searchData.FaceMatches.length > 0) {
            finalFaceId = searchData.FaceMatches[0].Face.FaceId;
            console.log(`Matched existing face: ${finalFaceId}`);
        }

        await saveFaceMetadata(finalFaceId, `face/${key}`);
        console.log(`👤 Face indexed: ${finalFaceId}`);
    } catch (err) {
        console.error("❌ Error processing image:", err.message);
        throw err;
    }
}

module.exports = { handleImageUpload };