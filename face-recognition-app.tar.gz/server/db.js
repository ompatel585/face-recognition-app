const AWS = require('aws-sdk');

AWS.config.update({ region: 'ap-south-1' });

const dynamo = new AWS.DynamoDB.DocumentClient();
const TABLE = 'FaceMetadata';

async function saveFaceMetadata(faceId, imageKey, name = 'Unknown') {
    const item = {
        FaceId: faceId,
        ImageKey: imageKey.startsWith('face/') ? imageKey : `face/${imageKey}`,
        Name: name,
        CollectionId: 'face-collection-om',
        Timestamp: new Date().toISOString(),
        GroupId: faceId
    };

    try {
        await dynamo.put({
            TableName: TABLE,
            Item: item
        }).promise();
        console.log("✅ Face metadata saved to DynamoDB");
    } catch (err) {
        console.error("❌ Error saving metadata:", err.message);
        throw err;
    }
}

async function listAllFaces() {
    try {
        const data = await dynamo.scan({ TableName: TABLE }).promise();
        return data.Items;
    } catch (err) {
        console.error("❌ Error listing faces:", err.message);
        throw err;
    }
}

async function assignName(faceId, name) {
    try {
        await dynamo.update({
            TableName: TABLE,
            Key: { FaceId: faceId },
            UpdateExpression: 'SET #n = :name',
            ExpressionAttributeNames: { '#n': 'Name' },
            ExpressionAttributeValues: { ':name': name }
        }).promise();
        console.log("✅ Name updated in DynamoDB");
    } catch (err) {
        console.error("❌ Error updating name:", err.message);
        throw err;
    }
}

module.exports = { saveFaceMetadata, listAllFaces, assignName };